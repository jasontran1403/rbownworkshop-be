package com.rbownworkshop.server.service;

import com.rbownworkshop.server.exception.RateLimitException;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Service
public class RateLimitService {

    // Sliding window: tối đa 20 request / 60s / IP
    private static final int MAX_REQUESTS = 20;
    private static final long WINDOW_MS = 60_000L;

    private final Map<String, Deque<Long>> store = new ConcurrentHashMap<>();

    public void check(String key) {
        long now = Instant.now().toEpochMilli();
        Deque<Long> queue = store.computeIfAbsent(key, k -> new ArrayDeque<>());

        synchronized (queue) {
            while (!queue.isEmpty() && now - queue.peekFirst() > WINDOW_MS) {
                queue.pollFirst();
            }
            if (queue.size() >= MAX_REQUESTS) {
                throw new RateLimitException("Bạn đã tìm kiếm quá nhiều. Vui lòng thử lại sau ít phút.");
            }
            queue.addLast(now);
        }
    }
}